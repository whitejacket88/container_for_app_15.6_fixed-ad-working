//===----------------------------------------------------------------------===//
// Copyright © 2026 Apple Inc. and the container project authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//===----------------------------------------------------------------------===//

import ContainerTestSupport
import Foundation
import Testing

/// Tests that stop, kill, and delete return errors for non-existent containers.
@Suite
struct TestCLINotFound {

    @Test func testStopNonExistentContainer() async throws {
        try await ContainerFixture.with { f in
            let result = try f.run(["stop", "does-not-exist"])
            #expect(result.status != 0, "stop should fail for a non-existent container")
        }
    }

    @Test func testKillNonExistentContainer() async throws {
        try await ContainerFixture.with { f in
            let result = try f.run(["kill", "does-not-exist"])
            #expect(result.status != 0, "kill should fail for a non-existent container")
        }
    }

    @Test func testDeleteNonExistentContainer() async throws {
        try await ContainerFixture.with { f in
            let result = try f.run(["delete", "does-not-exist"])
            #expect(result.status != 0, "delete should fail for a non-existent container")
        }
    }
}
