//===----------------------------------------------------------------------===//
// Copyright © 2026 Apple Inc. and the container project authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//===----------------------------------------------------------------------===//

import ArgumentParser
import ContainerAPIClient
import ContainerLog
import ContainerizationError
import Foundation
import Logging

struct BuilderStop: AsyncParsableCommand {
    public static var configuration: CommandConfiguration {
        var config = CommandConfiguration()
        config.commandName = "stop"
        config.abstract = "Stop the builder container"
        return config
    }

    @OptionGroup
    public var logOptions: Flags.Logging

    public init() {}

    var log: Logger {
        var logger = Logger(label: "container", factory: { _ in StderrLogHandler() })
        logger.logLevel = logOptions.debug ? .debug : .info
        return logger
    }

    public func run() async throws {
        do {
            let client = ContainerClient()
            try await client.stop(id: "buildkit")
        } catch {
            if error is ContainerizationError {
                if (error as? ContainerizationError)?.code == .notFound {
                    log.warning("builder is not running")
                    return
                }
            }
            throw error
        }
    }
}
