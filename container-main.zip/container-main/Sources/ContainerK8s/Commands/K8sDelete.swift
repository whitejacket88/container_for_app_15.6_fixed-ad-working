//===----------------------------------------------------------------------===//
// Copyright © 2026 Apple Inc. and the container project authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//===----------------------------------------------------------------------===//

import ArgumentParser
import ContainerAPIClient
import ContainerLog
import ContainerResource
import ContainerizationError
import Logging

public struct K8sDelete: AsyncParsableCommand {
    public init() {}

    public static let configuration = CommandConfiguration(
        commandName: "delete",
        abstract: "Delete a Kubernetes cluster and its nodes",
        aliases: ["rm"]
    )

    @Option(name: .long, help: "Cluster name")
    var name: String = K8sHelper.defaultName

    public func run() async throws {
        LoggingSystem.bootstrap { _ in StderrLogHandler() }
        let log = Logger(label: K8sHelper.pluginName)

        let client = ContainerClient()

        let clusterContainer = try? await client.get(id: name)
        if let container = clusterContainer {
            guard container.configuration.labels[ResourceLabelKeys.plugin] == K8sHelper.pluginName else {
                log.error("container is not a k8s cluster, refusing delete", metadata: ["name": "\(name)"])
                throw ContainerizationError(.invalidArgument, message: "\(name) is not a k8s cluster")
            }
        }

        let workerNames = (try? await K8sHelper.workerContainerNames(clusterName: name, client: client)) ?? []
        var failures: [(name: String, error: Error)] = []

        for workerName in workerNames {
            do {
                try? await client.stop(id: workerName)
                try await client.delete(id: workerName)
            } catch let error as ContainerizationError where error.code == .notFound || (error.cause as? ContainerizationError)?.code == .notFound {
                log.debug("worker container not found, skipping delete", metadata: ["name": "\(workerName)"])
            } catch {
                log.error("failed to delete worker container", metadata: ["name": "\(workerName)", "error": "\(error)"])
                failures.append((workerName, error))
            }
        }

        do {
            try? await client.stop(id: name)
            try await client.delete(id: name)
        } catch let error as ContainerizationError where error.code == .notFound || (error.cause as? ContainerizationError)?.code == .notFound {
            log.debug("cluster container not found, skipping delete", metadata: ["name": "\(name)"])
        } catch {
            log.error("failed to delete cluster container", metadata: ["name": "\(name)", "error": "\(error)"])
            failures.append((name, error))
        }

        // Only touch the kubeconfig for a cluster we found. Otherwise the entries
        // named `name` belong to someone else, so leave them alone.
        if clusterContainer != nil || !workerNames.isEmpty {
            try K8sHelper.removeConfig(containerId: name, log: log)
        } else {
            log.debug("no cluster container found, leaving kubeconfig untouched", metadata: ["name": "\(name)"])
        }

        guard failures.isEmpty else {
            let details = failures.map { "\($0.name): \($0.error)" }.joined(separator: "; ")
            throw ContainerizationError(.internalError, message: "failed to delete node(s): \(details)")
        }

        print(name)
    }
}
