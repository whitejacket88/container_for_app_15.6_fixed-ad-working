//===----------------------------------------------------------------------===//
// Copyright © 2026 Apple Inc. and the container project authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//===----------------------------------------------------------------------===//

import ArgumentParser
import ContainerAPIClient
import Containerization
import ContainerizationOCI

extension Application {
    public struct RegistryLogout: AsyncLoggableCommand {
        public init() {}
        public static let configuration = CommandConfiguration(
            commandName: "logout",
            abstract: "Log out from a registry"
        )

        @OptionGroup
        public var logOptions: Flags.Logging

        @Argument(help: "Registry server name")
        var registry: String

        public func run() async throws {
            let keychain = KeychainHelper(securityDomain: Constants.keychainID)
            let r = Reference.resolveDomain(domain: registry)
            try keychain.delete(hostname: r)
        }
    }
}
